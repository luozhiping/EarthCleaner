package xfocus.game.controllers;

import android.graphics.Canvas;
import android.graphics.Paint;
/*
 * ���˵�
 */
public class GameMenu {
	public GameMenu() {
		
	}
	
	public void doDraw(Canvas canvas) {
		
	}
	
	public void logic() {
		
	}
}
