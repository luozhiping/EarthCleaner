package xfocus.game.controllers;

import android.graphics.Canvas;
import android.graphics.Paint;
/*
 * ��������
 */
public class About {
	public About() {

	}

	public void doDraw(Canvas canvas, Paint paint) {

	}

	public void logic() {

	}
}
