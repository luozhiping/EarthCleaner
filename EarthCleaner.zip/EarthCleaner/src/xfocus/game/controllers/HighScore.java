package xfocus.game.controllers;

import android.graphics.Canvas;
import android.graphics.Paint;
/*
 * ��߷�
 */
public class HighScore {
	public HighScore() {

	}

	public void doDraw(Canvas canvas, Paint paint) {

	}

	public void logic() {

	}
}
